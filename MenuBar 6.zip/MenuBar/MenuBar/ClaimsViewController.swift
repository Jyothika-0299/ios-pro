import UIKit

class ClaimsViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    // Outlets for the text fields and buttons
    @IBOutlet var claimNO: UITextField!
    @IBOutlet var claimDate: UITextField!
    @IBOutlet var PolicyNo: UITextField!
    @IBOutlet var InciDate: UITextField!
    @IBOutlet var InciLoc: UITextField!
    @IBOutlet var InciDes: UITextField!
    @IBOutlet var ClaimAmt: UITextField!
    @IBOutlet var SurvyName: UITextField!
    @IBOutlet var SurvyPhn: UITextField!
    @IBOutlet var SurvyDate: UITextField!
    @IBOutlet var SurvyDes: UITextField!
    @IBOutlet var ClaimStat: UITextField!
    
    @IBOutlet var Fetch: UIButton!
    @IBOutlet var Save: UIButton!
    @IBOutlet var update: UIButton!
    @IBOutlet var Delete: UIButton!
    
    var Cno: String?
    var CDat: String?
    var PolNo: String?
    var IndDat: String?
    var IndLoc: String?
    var IndDes: String?
    var CAmt: String?
    var SuryNam: String?
    var SuryPhn: String?
    var SuryDat: String?
    var SuryDes: String?
    var Cst: String?


    var pv1: UIPickerView!
    var ClaimStatus: [String] = []
    
    var dp1: UIDatePicker!
    var df1: DateFormatter!
    
    var dp2: UIDatePicker!
    var df2: DateFormatter!
    
    var dp3: UIDatePicker!
    var df3: DateFormatter!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Initialize claim statuses for the picker view
        ClaimStatus = ["S", "A", "R","T"]
        
        // Set up the UIPickerView for ClaimStatus
        pv1 = UIPickerView()
        pv1.delegate = self
        pv1.dataSource = self
        ClaimStat.inputView = pv1
        
        // Set up the UIDatePickers for the dates
        dp1 = UIDatePicker()
        dp1.datePickerMode = .date
        dp1.preferredDatePickerStyle = .wheels
        dp1.addTarget(self, action: #selector(dp1Click), for: .valueChanged)
        SurvyDate.inputView = dp1
        
        dp2 = UIDatePicker()
        dp2.datePickerMode = .date
        dp2.preferredDatePickerStyle = .wheels
        dp2.addTarget(self, action: #selector(dp2Click), for: .valueChanged)
        claimDate.inputView = dp2
        
        dp3 = UIDatePicker()
        dp3.datePickerMode = .date
        dp3.preferredDatePickerStyle = .wheels
        dp3.addTarget(self, action: #selector(dp3Click), for: .valueChanged)
        InciDate.inputView = dp3
    }
    
    
    @IBAction func ClickSave(_ sender: UIButton) {
        // Validate the input fields
        guard let Cno = claimNO.text, !Cno.isEmpty,
              let CDat = claimDate.text, !CDat.isEmpty,
              let PolNo = PolicyNo.text, !PolNo.isEmpty,
              let IndDat = InciDate.text, !IndDat.isEmpty,
              let IndLoc = InciLoc.text, !IndLoc.isEmpty,
              let IndDes = InciDes.text, !IndDes.isEmpty,
              let CAmt = ClaimAmt.text, !CAmt.isEmpty,
              let SuryNam = SurvyName.text, !SuryNam.isEmpty,
              let SuryPhn = SurvyPhn.text, !SuryPhn.isEmpty,
              let SuryDa = SurvyDate.text, !SuryDa.isEmpty,
              let SuryDes = SurvyDes.text, !SuryDes.isEmpty,
              let Cst = ClaimStat.text, !Cst.isEmpty else {
            showAlert(message: "Please fill in all fields.")
            return
        }
        

        
        // Create POST request for saving the claim
        guard let webserviceURL = URL(string: "https://abzclaimwebapi-chana.azurewebsites.net/api/Claim") else {
            print("Invalid URL")
            return
        }
        
        
        var request = URLRequest(url: webserviceURL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let ClaimData: [String: Any] = [
            "ClaimNo": Cno,
            "ClaimDate": CDat,
            "PolicyNo": PolNo,
            "IncidentDate": IndDat,
            "IncidentLocation": IndLoc,
            "IncidentDescription": IndDes,
            "ClaimAmount": CAmt,
            "SurveyorName": SuryNam,
            "SurveyorPhone": SuryPhn,
            "SurveyDate": SuryDa, // This should match server field name
            "SurveyDescription": SuryDes,
            "ClaimStatus": Cst
        ]


        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: ClaimData, options: [])
            if let jsonString = String(data: jsonData, encoding: .utf8) {
                print("Request Body: \(jsonString)")
            }
            request.httpBody = jsonData
        } catch {
            print("Failed to serialize JSON: \(error.localizedDescription)")
            return
        }
        
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.showAlert(message: "Request failed: \(error.localizedDescription)")
                }
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse {
                if (200...299).contains(httpResponse.statusCode) {
                    if let data = data {
                        do {
                            let jsonResponse = try JSONSerialization.jsonObject(with: data, options: [])
                            print("Response: \(jsonResponse)")
                            DispatchQueue.main.async {
                                self.showAlert(message: "Claim saved successfully.")
                            }
                        } catch {
                            print("Failed to parse response JSON: \(error.localizedDescription)")
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        self.showAlert(message: "Server returned status code: \(httpResponse.statusCode)")
                    }
                }
            }
        }
        task.resume()
    }
    
    
    
    
    
    @IBAction func ClickFetch(_ sender: UIButton) {
        guard let Cno = claimNO.text, !Cno.isEmpty else {
            showAlert(message: "Please enter a Claim Number to fetch.")
            return
        }

        guard let webserviceURL = URL(string: "https://abzclaimwebapi-chana.azurewebsites.net/api/Claim/\(Cno)") else {
            print("Invalid URL")
            return
        }

        var request = URLRequest(url: webserviceURL)
        request.httpMethod = "GET"

        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.showAlert(message: "Request failed: \(error.localizedDescription)")
                }
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                if (200...299).contains(httpResponse.statusCode) {
                    if let data = data {
                        do {
                            let jsonResponse = try JSONSerialization.jsonObject(with: data, options: [])
                            print("Response: \(jsonResponse)")
                            DispatchQueue.main.async {
                                // Populate the UI with the fetched data
                                // Example: self.claimDate.text = fetchedData["ClaimDate"] as? String
                                self.showAlert(message: "Claim fetched successfully.")
                            }
                        } catch {
                            print("Failed to parse response JSON: \(error.localizedDescription)")
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        self.showAlert(message: "Server returned status code: \(httpResponse.statusCode)")
                    }
                }
            }
        }
        task.resume()
    }

    
    
    @IBAction func ClickDelete(_ sender: UIButton) {
        guard let Cno = claimNO.text, !Cno.isEmpty else {
            showAlert(message: "Please enter a Claim Number to delete.")
            return
        }

        guard let webserviceURL = URL(string: "https://abzclaimwebapi-chana.azurewebsites.net/api/Claim/\(Cno)") else {
            print("Invalid URL")
            return
        }

        var request = URLRequest(url: webserviceURL)
        request.httpMethod = "DELETE"

        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.showAlert(message: "Request failed: \(error.localizedDescription)")
                }
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                if (200...299).contains(httpResponse.statusCode) {
                    DispatchQueue.main.async {
                        self.showAlert(message: "Claim deleted successfully.")
                    }
                } else {
                    DispatchQueue.main.async {
                        self.showAlert(message: "Server returned status code: \(httpResponse.statusCode)")
                    }
                }
            }
        }
        task.resume()
    }

    
    
    @IBAction func ClickUpdate(_ sender: UIButton) {
        guard let Cno = claimNO.text, !Cno.isEmpty,
              let CDat = claimDate.text, !CDat.isEmpty,
              let PolNo = PolicyNo.text, !PolNo.isEmpty else {
            showAlert(message: "Please ensure all fields are filled in for update.")
            return
        }

        guard let webserviceURL = URL(string: "https://abzclaimwebapi-chana.azurewebsites.net/api/Claim/\(Cno)") else {
            print("Invalid URL")
            return
        }

        var request = URLRequest(url: webserviceURL)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let updatedClaimData: [String: Any] = [
            "ClaimNo": Cno,
            "ClaimDate": CDat,
            "PolicyNo": PolNo,
            // Add other fields you want to update
        ]

        do {
            let jsonData = try JSONSerialization.data(withJSONObject: updatedClaimData, options: [])
            request.httpBody = jsonData
        } catch {
            print("Failed to serialize JSON: \(error.localizedDescription)")
            return
        }

        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.showAlert(message: "Request failed: \(error.localizedDescription)")
                }
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                if (200...299).contains(httpResponse.statusCode) {
                    DispatchQueue.main.async {
                        self.showAlert(message: "Claim updated successfully.")
                    }
                } else {
                    DispatchQueue.main.async {
                        self.showAlert(message: "Server returned status code: \(httpResponse.statusCode)")
                    }
                }
            }
        }
        task.resume()
    }

    

    
    
    
    // Helper method to show alert messages
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Notification", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
            return 1
        }
        
        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            return ClaimStatus.count
        }
        
        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            return ClaimStatus[row]
        }
        
        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            ClaimStat.text = ClaimStatus[row]
        }
        
        func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
            return 40
        }
    
    

    @objc func dp1Click() {
        let isoFormatter = ISO8601DateFormatter()
        isoFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        isoFormatter.timeZone = TimeZone(secondsFromGMT: 0) // UTC time zone

        SurvyDate.text = isoFormatter.string(from: dp1.date)
    }

    
    @objc func dp2Click() {
        let isoFormatter = ISO8601DateFormatter()
        isoFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        isoFormatter.timeZone = TimeZone(secondsFromGMT: 0) // UTC time zone

        claimDate.text = isoFormatter.string(from: dp2.date)
    }

    
    @objc func dp3Click() {
        let isoFormatter = ISO8601DateFormatter()
        isoFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        isoFormatter.timeZone = TimeZone(secondsFromGMT: 0) // UTC time zone

        InciDate.text = isoFormatter.string(from: dp3.date)
    }

    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        SurvyDate.resignFirstResponder()
        claimDate.resignFirstResponder()
        InciDate.resignFirstResponder()
        ClaimStat.resignFirstResponder()
    }
    
}

